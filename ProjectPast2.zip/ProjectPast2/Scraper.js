import axios from "axios";
import * as cheerio from "cheerio";
import chalk from 'chalk';
import { loadSpacy } from 'node-spacy';

const response = await axios.get("https://en.wikipedia.org/wiki/Lemur");
const html = response.data;

// Function for cheerio parses HTML
const $ = cheerio.load(html);

let currentHeader = null;

// Load English spaCy model
const nlp = await loadSpacy("en_core_web_sm");

// Define your keyword relevance criteria
const importantKeywords = ["endangered", "species", "habitat"];

// Loop through the content
$(".mw-parser-output").children().each((index, element) => {
    if ($(element).is("h2")) {
        // If the element is an <h2> header, set it as the current header and log it in green
        currentHeader = $(element).text().trim();
        console.log(chalk.green(currentHeader));
    } else if ($(element).is("p")) {
        // If the element is a <p> paragraph, assign it the header "filler" if no header is present
        if (!currentHeader) {
            currentHeader = "filler";
        }
        const text = $(element).text().trim();
        
        // Tokenize the paragraph using spaCy
        const doc = nlp(text);
        
        // Calculate TF-IDF scores for keywords
        const keywordScores = {};
        for (const keyword of importantKeywords) {
            const keywordScore = doc
                .pipe(nlp.tfidf())
                .pipe(nlp.extractKeyword({ keyword: keyword }))
                .doc
                .user_data.tfidf;
            keywordScores[keyword] = keywordScore;
        }
        
        // Calculate a combined importance score for the bullet point
        const importanceScore = Object.values(keywordScores).reduce((acc, score) => acc + score, 0);
        
        // Display the bullet point if it meets the importance criteria
        if (importanceScore > 0) {
            console.log(chalk.white(`[${currentHeader}] • ${text}`));
        }
    }
});
