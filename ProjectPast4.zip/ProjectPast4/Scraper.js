import axios from "axios";
import * as cheerio from "cheerio";
import chalk from 'chalk';
import tokenizer from 'sentence-tokenizer';

const response = await axios.get("https://en.wikipedia.org/wiki/Lemur");
const html = response.data;

// Function for cheerio parses HTML
const $ = cheerio.load(html);

// Initialize tokenizer
const sentenceTokenizer = new tokenizer();

let currentHeader = null; // Initialize the CURRENT header
let textwallExists = false; // Flag to track if a text wall exists
let keywordCriteria = []; // Initialize an array to store keyword criteria for each text wall

// Loop through content
$(".mw-parser-output").children().each((index, element) => {
    if ($(element).is("h2")) {
        // If the element is a <h2> header, set it as the CURRENT header and log it in green
        currentHeader = $(element).text().trim();
        
        // Reset textwall flag for new textwall
        textwallExists = false;

        // Push the current header as the keyword criteria for this text wall
        keywordCriteria.push(currentHeader);
    } else if ($(element).is("p") && !textwallExists) {
        const text = $(element).text().trim();
        
        // Tokenize the paragraph into sentences
        sentenceTokenizer.setEntry(text);
        const sentences = sentenceTokenizer.getSentences();

        // Initialize an array to store dot points within the textwall
        const dotPoints = [];

        // Calculate relevance score for each sentence based on criteria
        sentences.forEach(sentence => {
            const relevanceScore = keywordCriteria.reduce((score, keyword) => {
                if (sentence.toLowerCase().includes(keyword.toLowerCase())) {
                    return score + 1; // Increase score on relevant keywords
                }
                return score;
            }, 0);

            // Stores each sentence as a dot point along with its relevance score
            dotPoints.push({ sentence, relevanceScore });
        });

        // Sort dot points by relevance score in descending order
        dotPoints.sort((a, b) => b.relevanceScore - a.relevanceScore);

        // If the current header is null, display it as "Introduction" (doesnt really work, not main priority)
        if (!currentHeader) {
            currentHeader = "Introduction";
        }

        // Display the header for the textwall
        console.log(chalk.green(currentHeader));

        // Display only the top three most relevant dot points in pink
        dotPoints.slice(0, 3).forEach(dotPoint => {
            console.log(chalk.magenta(`• ${dotPoint.sentence}`)); // Pink color for the top 3
        });

        // Set the textwall flag to true to prevent additional text walls in this section
        textwallExists = true;
    }
});
