// Text : Image
import axios from "axios";
import * as cheerio from "cheerio";
import chalk from 'chalk';

const response = await axios.get("https://en.wikipedia.org/wiki/Lemur");
const html = response.data;

// Function for cheerio parses HTML
const $ = cheerio.load(html);

// Function to select all the elements with the class name desired
const Header = $(".mw-parser-output p, h2");
const Para = $(".mw-parser-output p, h2");

Header(chalk.white);
Para(chalk.green);

// Loop through the elements
for (const article of Header) {
	const text = $(article).text().trim();
    // Log each article's text content to the console
    console.log(text);

// Loop through the elements
for (const article of Para) {
	const text = $(article).text().trim();
    // Log each article's text content to the console
    console.log(text);