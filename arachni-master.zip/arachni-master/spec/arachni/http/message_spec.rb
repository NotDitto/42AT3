require 'spec_helper'

describe Arachni::HTTP::Message do
    it_should_behave_like 'Arachni::HTTP::Message'
end
