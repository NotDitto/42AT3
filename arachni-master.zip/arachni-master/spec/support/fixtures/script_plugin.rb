register_results 'I\'m a script!'
