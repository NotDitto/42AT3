import axios from "axios";
import * as cheerio from "cheerio";
import chalk from 'chalk';
import tokenizer from 'sentence-tokenizer'; // Import the 'sentence-tokenizer' package

const response = await axios.get("https://en.wikipedia.org/wiki/Lemur");
const html = response.data;

// Function for cheerio parses HTML
const $ = cheerio.load(html);

let currentHeader = null;

// Define your keyword relevance criteria
const importantKeywords = ["endangered", "species", "habitat"];

// Initialize a sentence tokenizer
const sentenceTokenizer = new tokenizer();

// Loop through the content
$(".mw-parser-output").children().each((index, element) => {
    if ($(element).is("h2")) {
        // If the element is an <h2> header, set it as the current header and log it in green
        currentHeader = $(element).text().trim();
    } else if ($(element).is("p")) {
        // If the element is a <p> paragraph, assign it the header "filler" if no header is present
        if (!currentHeader) {
            currentHeader = "filler";
        }
        const text = $(element).text().trim();
        
        // Tokenize the paragraph into sentences
        sentenceTokenizer.setEntry(text);
        const sentences = sentenceTokenizer.getSentences();

        // Initialize variables to keep track of the most relevant sentence
        let mostRelevantSentence = null;
        let mostRelevanceScore = 0;

        // Calculate a relevance score for each sentence based on your criteria
        sentences.forEach(sentence => {
            const relevanceScore = importantKeywords.reduce((score, keyword) => {
                if (sentence.toLowerCase().includes(keyword.toLowerCase())) {
                    return score + 1; // Increase score for relevant keywords
                }
                return score;
            }, 0);

            // Check if this sentence is more relevant than the current most relevant one
            if (relevanceScore > mostRelevanceScore) {
                mostRelevantSentence = sentence;
                mostRelevanceScore = relevanceScore;
            }
        });

        // Display the header only once for each paragraph
        if (currentHeader !== "filler") {
            console.log(chalk.green(currentHeader));
        }

        // Display each sentence with the most relevant as pink and the rest as white
        sentences.forEach(sentence => {
            if (sentence === mostRelevantSentence) {
                console.log(chalk.magenta(`• ${sentence}`)); // Pink color for the most relevant
            } else {
                console.log(chalk.white(`• ${sentence}`)); // Yellow color for others
            }
        });

        // Reset the header for the next paragraph
        currentHeader = null;
    }
});
