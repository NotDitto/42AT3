import axios from "axios";
import * as cheerio from "cheerio";
import chalk from 'chalk';

const response = await axios.get("https://en.wikipedia.org/wiki/Lemur");
const html = response.data;

// Function for cheerio parses HTML
const $ = cheerio.load(html);

let currentHeader = null;

// Loop through the content & tag class elements
$(".mw-parser-output").children().each((index, element) => {
    const text = $(element).text().trim();
    if ($(element).is("h2")) {
        // If the element is an <h2> header, set it as the current header and greenify
        currentHeader = $(element).text().trim();
        console.log(chalk.green(currentHeader));
    } else if ($(element).is("p") && currentHeader) {
        // If the element is a <p> paragraph and there is no current header, assign it the header "filler"
        if (!currentHeader) {
            currentHeader = "filler";
        }
        // log it with the associated header whitified
        console.log(chalk[currentHeader === "filler" ? "green" : "white"](`[${currentHeader}] ${text}`));
    }
});
