import axios from "axios";
import * as cheerio from "cheerio";
import chalk from 'chalk';
import { naturalLanguage } from 'apache-opennlp-2.3.0'; // Replace with an actual NLP library

const response = await axios.get("https://en.wikipedia.org/wiki/Lemur");
const html = response.data;

// Function for cheerio parses HTML
const $ = cheerio.load(html);

let currentHeader = null;

// Function to extract key points from a paragraph without altering the information
function extractKeyPoints(text) {
    const sentences = text.split('.'); // Split the paragraph into sentences
    const keyPoints = sentences.map(sentence => sentence.trim()).filter(sentence => sentence.length > 0);
    return keyPoints;
}


// Loop through the content
$(".mw-parser-output").children().each((index, element) => {
    const text = $(element).text().trim();
    if ($(element).is("h2")) {
        // If the element is an <h2> header, set it as the current header and log it in green
        currentHeader = $(element).text().trim();
        console.log(chalk.green(currentHeader));
    } else if ($(element).is("p")) {
        // If the element is a <p> paragraph, assign it the header "filler" and log key points in white
        if (!currentHeader) {
            currentHeader = "filler";
        }
        const isKeyPoint = text.includes('.'); // Check if the paragraph is split into sentences
        const keyPoints = isKeyPoint ? extractKeyPoints(text) : [text];
        
        keyPoints.forEach((keyPoint, index) => {
            console.log(chalk.white(`[${currentHeader}] Key Point ${index + 1}: ${keyPoint}`));
        });
    }
});
